def say_hello(name):
    return f"Hello, {name}"


def mult(a,b):
    return a*b